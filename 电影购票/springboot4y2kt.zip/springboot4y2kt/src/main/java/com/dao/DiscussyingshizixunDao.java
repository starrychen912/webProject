package com.dao;

import com.entity.DiscussyingshizixunEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.DiscussyingshizixunVO;
import com.entity.view.DiscussyingshizixunView;


/**
 * 影视资讯评论表
 * 
 * @author 
 * @email 
 * @date 2022-04-13 10:26:01
 */
public interface DiscussyingshizixunDao extends BaseMapper<DiscussyingshizixunEntity> {
	
	List<DiscussyingshizixunVO> selectListVO(@Param("ew") Wrapper<DiscussyingshizixunEntity> wrapper);
	
	DiscussyingshizixunVO selectVO(@Param("ew") Wrapper<DiscussyingshizixunEntity> wrapper);
	
	List<DiscussyingshizixunView> selectListView(@Param("ew") Wrapper<DiscussyingshizixunEntity> wrapper);

	List<DiscussyingshizixunView> selectListView(Pagination page,@Param("ew") Wrapper<DiscussyingshizixunEntity> wrapper);
	
	DiscussyingshizixunView selectView(@Param("ew") Wrapper<DiscussyingshizixunEntity> wrapper);
	

}
