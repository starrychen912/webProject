package com.dao;

import com.entity.YingshizixunEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.YingshizixunVO;
import com.entity.view.YingshizixunView;


/**
 * 影视资讯
 * 
 * @author 
 * @email 
 * @date 2022-04-13 10:26:01
 */
public interface YingshizixunDao extends BaseMapper<YingshizixunEntity> {
	
	List<YingshizixunVO> selectListVO(@Param("ew") Wrapper<YingshizixunEntity> wrapper);
	
	YingshizixunVO selectVO(@Param("ew") Wrapper<YingshizixunEntity> wrapper);
	
	List<YingshizixunView> selectListView(@Param("ew") Wrapper<YingshizixunEntity> wrapper);

	List<YingshizixunView> selectListView(Pagination page,@Param("ew") Wrapper<YingshizixunEntity> wrapper);
	
	YingshizixunView selectView(@Param("ew") Wrapper<YingshizixunEntity> wrapper);
	

}
