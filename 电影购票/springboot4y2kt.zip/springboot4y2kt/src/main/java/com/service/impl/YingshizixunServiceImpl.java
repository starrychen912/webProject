package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.YingshizixunDao;
import com.entity.YingshizixunEntity;
import com.service.YingshizixunService;
import com.entity.vo.YingshizixunVO;
import com.entity.view.YingshizixunView;

@Service("yingshizixunService")
public class YingshizixunServiceImpl extends ServiceImpl<YingshizixunDao, YingshizixunEntity> implements YingshizixunService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<YingshizixunEntity> page = this.selectPage(
                new Query<YingshizixunEntity>(params).getPage(),
                new EntityWrapper<YingshizixunEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<YingshizixunEntity> wrapper) {
		  Page<YingshizixunView> page =new Query<YingshizixunView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<YingshizixunVO> selectListVO(Wrapper<YingshizixunEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public YingshizixunVO selectVO(Wrapper<YingshizixunEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<YingshizixunView> selectListView(Wrapper<YingshizixunEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public YingshizixunView selectView(Wrapper<YingshizixunEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
