package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.DiscussyingshizixunEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.DiscussyingshizixunVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.DiscussyingshizixunView;


/**
 * 影视资讯评论表
 *
 * @author 
 * @email 
 * @date 2022-04-13 10:26:01
 */
public interface DiscussyingshizixunService extends IService<DiscussyingshizixunEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<DiscussyingshizixunVO> selectListVO(Wrapper<DiscussyingshizixunEntity> wrapper);
   	
   	DiscussyingshizixunVO selectVO(@Param("ew") Wrapper<DiscussyingshizixunEntity> wrapper);
   	
   	List<DiscussyingshizixunView> selectListView(Wrapper<DiscussyingshizixunEntity> wrapper);
   	
   	DiscussyingshizixunView selectView(@Param("ew") Wrapper<DiscussyingshizixunEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<DiscussyingshizixunEntity> wrapper);
   	

}

