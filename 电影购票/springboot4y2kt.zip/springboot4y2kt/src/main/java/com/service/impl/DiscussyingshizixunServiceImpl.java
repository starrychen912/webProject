package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.DiscussyingshizixunDao;
import com.entity.DiscussyingshizixunEntity;
import com.service.DiscussyingshizixunService;
import com.entity.vo.DiscussyingshizixunVO;
import com.entity.view.DiscussyingshizixunView;

@Service("discussyingshizixunService")
public class DiscussyingshizixunServiceImpl extends ServiceImpl<DiscussyingshizixunDao, DiscussyingshizixunEntity> implements DiscussyingshizixunService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<DiscussyingshizixunEntity> page = this.selectPage(
                new Query<DiscussyingshizixunEntity>(params).getPage(),
                new EntityWrapper<DiscussyingshizixunEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<DiscussyingshizixunEntity> wrapper) {
		  Page<DiscussyingshizixunView> page =new Query<DiscussyingshizixunView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<DiscussyingshizixunVO> selectListVO(Wrapper<DiscussyingshizixunEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public DiscussyingshizixunVO selectVO(Wrapper<DiscussyingshizixunEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<DiscussyingshizixunView> selectListView(Wrapper<DiscussyingshizixunEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public DiscussyingshizixunView selectView(Wrapper<DiscussyingshizixunEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
