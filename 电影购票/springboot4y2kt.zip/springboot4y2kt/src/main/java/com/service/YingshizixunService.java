package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.YingshizixunEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.YingshizixunVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.YingshizixunView;


/**
 * 影视资讯
 *
 * @author 
 * @email 
 * @date 2022-04-13 10:26:01
 */
public interface YingshizixunService extends IService<YingshizixunEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<YingshizixunVO> selectListVO(Wrapper<YingshizixunEntity> wrapper);
   	
   	YingshizixunVO selectVO(@Param("ew") Wrapper<YingshizixunEntity> wrapper);
   	
   	List<YingshizixunView> selectListView(Wrapper<YingshizixunEntity> wrapper);
   	
   	YingshizixunView selectView(@Param("ew") Wrapper<YingshizixunEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<YingshizixunEntity> wrapper);
   	

}

