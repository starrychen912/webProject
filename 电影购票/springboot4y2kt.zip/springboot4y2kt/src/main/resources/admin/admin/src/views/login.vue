<template>
  <div>
        <div class="container loginIn">

      <!-- <div :class="2 == 1 ? 'left' : 2 == 2 ? 'left center' : 'left right'">
        <el-form class="login-form" label-position="left" :label-width="1 == 3 || 1 == 2 ? '30px': '0px'">
          <div class="title-container"><h3 class="title">鱼头影视登录</h3></div>
          <el-form-item :style='{"padding":"0","boxShadow":"0 0 6px rgba(0,0,0,0)","margin":"0 0 12px 0","borderColor":"rgba(0,0,0,0)","backgroundColor":"rgba(0,0,0,0)","borderRadius":"0","borderWidth":"0","width":"50%","borderStyle":"solid","height":"auto"}' :label="1 == 3 ? '用户名' : ''" :class="'style'+1">
            <span v-if="1 != 3" class="svg-container" style="
			color:rgba(0, 0, 0, 1);
			line-height:30px;
			font-size:14px;
			width:30px;
			padding:0;
			margin:0;
			radius:0;
			border-width:0;
			border-style:solid;
			border-color:rgba(0,0,0,0);
			background-color:rgba(0,0,0,0);
			box-shadow:0 0 6px rgba(0,0,0,0);
			}"><svg-icon icon-class="user" /></span>
            <el-input placeholder="请输入用户名" name="username" type="text" v-model="rulesForm.username" />
          </el-form-item>
          <el-form-item :style='{"padding":"0","boxShadow":"0 0 6px rgba(0,0,0,0)","margin":"0 0 12px 0","borderColor":"rgba(0,0,0,0)","backgroundColor":"rgba(0,0,0,0)","borderRadius":"0","borderWidth":"0","width":"50%","borderStyle":"solid","height":"auto"}' :label="1 == 3 ? '密码' : ''" :class="'style'+1">
            <span v-if="1 != 3" class="svg-container" style="color:rgba(0, 0, 0, 1);
			line-height:30px;
			font-size:14px;
			width:30px;
			padding:0;
			margin:0;
			radius:0;
			border-width:0;
			border-style:solid;
			border-color:rgba(0,0,0,0);
			background-color:rgba(0,0,0,0);
			box-shadow:0 0 6px rgba(0,0,0,0);"><svg-icon icon-class="password" /></span>
            <el-input placeholder="请输入密码" name="password" type="password" v-model="rulesForm.password" />
          </el-form-item>
          <el-form-item v-if="roles.length>1" label="角色" prop="loginInRole" class="role" style="display: flex;align-items: center;">
            <el-radio
              v-for="item in roles"
              v-bind:key="item.roleName"
              v-model="rulesForm.role"
              :label="item.roleName"
            >{{item.roleName}}</el-radio>
          </el-form-item>
          <el-form-item v-if="roles.length==1" label=" " prop="loginInRole" class="role" style="display: flex;align-items: center;">
          </el-form-item>
          <el-button type="primary" @click="login()" class="loginInBt">{{'1' == '1' ? '登录' : 'login'}}</el-button>
          <el-form-item class="setting">
          </el-form-item>
        </el-form>
      </div> -->
      <!-- <div style="padding:10px;color:white;"><h3 >鱼头影视后台管理</h3></div> -->
       <el-tabs v-model="activeName" :class="2 == 1 ? 'left' : 2 == 2 ? 'left center' : 'left right'">
    <el-tab-pane label="登录" name="first">
      <el-form ref="rulesForm" :model="rulesForm" label-width="80px">
  <el-form-item label="用户名:">
    <el-input  placeholder="请输入用户名" name="username" type="text" v-model="rulesForm.username" prefix-icon="el-icon-user-solid"></el-input>
  </el-form-item>
  <el-form-item label="密码:">
    <el-input placeholder="请输入密码" name="password" type="password" v-model="rulesForm.password" prefix-icon="el-icon-lock"></el-input>
  </el-form-item>
  <el-form-item v-if="roles.length>1"  prop="loginInRole" class="role" style="display: flex;align-items: center;">
            <el-radio
              v-for="item in roles"
              v-bind:key="item.roleName"
              v-model="rulesForm.role"
              :label="item.roleName"
            >{{item.roleName}}</el-radio>
          </el-form-item>
          <el-form-item v-if="roles.length==1" label=" " prop="loginInRole" class="role" style="display: flex;align-items: center;">
          </el-form-item>
  <el-button type="primary"  style="margin-left:75%;" @click="login()">{{'1' == '1' ? '登录' : 'login'}}</el-button>
      </el-form>
    </el-tab-pane>
    <el-tab-pane label="注册" name="second"  @tab-click="handleClick">
      <el-form ref="regForm" :model="regForm" label-width="100px">
      <el-form-item label="账号:" class="input" v-if="tableName=='yonghu'">
			  <el-input v-model="regForm.zhanghao" autocomplete="off" placeholder="请输入账号"  />
			</el-form-item>
			<!-- <div v-if="tableName=='yonghu'" class="input-group">
			   <div class="label">密码</div>
			   <div class="input-container">
			     <input v-model="regForm.mima" class="input" type="text" placeholder="密码">
			   </div>
			 </div> -->	<el-form-item label="姓名:" class="input">
			  <el-input v-model="regForm.xingming" autocomplete="off" placeholder="请输入用户名"  prefix-icon="el-icon-user-solid"/>
			</el-form-item>
			<el-form-item label="密码:" class="input" >
			  <el-input v-model="regForm.mima" autocomplete="off" placeholder="请输入密码" type="password" prefix-icon="el-icon-lock"/>
			</el-form-item>
			<el-form-item label="确认密码:" class="input" >
			  <el-input v-model="regForm.mima2" autocomplete="off" placeholder="请输入确认密码" type="password" prefix-icon="el-icon-lock"/>
			</el-form-item>
		<el-form-item label="手机号码:" class="input" >
			  <el-input v-model="regForm.shoujihaoma" autocomplete="off" placeholder="请输入手机号码"  prefix-icon="el-icon-phone"/>
			</el-form-item>
			<el-form-item label="邮箱:" class="input">
			  <el-input v-model="regForm.youxiang" autocomplete="off" placeholder="请输入邮箱" prefix-icon="el-icon-message" />
			</el-form-item>
			<!-- <div style="display: flex;flex-wrap: wrap;width: 100%;justify-content: center;"> -->
        <div class="btnGoup">
				<el-button class="btn"  style="margin-left:70%" type="primary" @click="register()">注册</el-button>
				<el-button class="btn close" type="primary" @click="close()">重置</el-button>
        </div>
			<!-- </div> -->
      </el-form>
    </el-tab-pane>
  </el-tabs>
    </div>
  </div>
</template>
<script>

import menu from "@/utils/menu";

export default {
  data() {
    return {
      form: {
          name: '',
          region: '',},
      activeName: 'first',
      rulesForm: {
        username: "",
        password: "",
        role: "",
        code: '',
      },
      // 注册数据
       regForm: {
      },
      rules: {},
      menus: [],
      roles: [],
      tableName: "yonghu",
      codes: [{
        num: 1,
        color: '#000',
        rotate: '10deg',
        size: '16px'
      },{
        num: 2,
        color: '#000',
        rotate: '10deg',
        size: '16px'
      },{
        num: 3,
        color: '#000',
        rotate: '10deg',
        size: '16px'
      },{
        num: 4,
        color: '#000',
        rotate: '10deg',
        size: '16px'
      }],
    };
  },
  mounted() {
	let menus = menu.list();
	this.menus = menus;
    for (let i = 0; i < this.menus.length; i++) {
      if (this.menus[i].hasBackLogin=='是') {
            this.roles.push(this.menus[i])
      }
    }
    
  },
  // created() {
  //   this.getRandCode()
	
  // },
  methods: {
    // register(tableName){
    //   this.$storage.set("loginTable", tableName);
    //   this.$router.push({path:'/register'})
    // },
    // 点击清空数据
    handleClick(){this.regForm=[]},
    
    // 登陆接口
    login() {
      if (!this.rulesForm.username) {
         this.$message.error("请输入用户名");
        return;
      }
      if (!this.rulesForm.password) {
         this.$message.error("请输入密码");
        return;
      } if(this.roles.length>1) {
          if (!this.rulesForm.role) {
             this.$message.error("请选择角色");
            return;
          }
          let menus = this.menus;
          for (let i = 0; i < menus.length; i++) {
            if (menus[i].roleName == this.rulesForm.role) {
              this.tableName = menus[i].tableName;
            }
          }
      } 
       else {
          this.tableName = this.roles[0].tableName;
          this.rulesForm.role = this.roles[0].roleName;
      }

      this.$http({
        url: `${this.tableName}/login?username=${this.rulesForm.username}&password=${this.rulesForm.password}`,
        method: "post"
      }).then(({ data }) => {
        if (data && data.code === 0) {
          this.$storage.set("Token", data.token);
          this.$storage.set("role", this.rulesForm.role);
          this.$storage.set("sessionTable", this.tableName);
          this.$storage.set("adminName", this.rulesForm.username);
          this.$router.replace({ path: "/index/" });
        } else {
          this.$message.error(data.msg);
        }
      });
    },
    // 注册接口
     // 注册
    register() {

	var url=this.tableName+"/register";
      if((!this.regForm.zhanghao) && `yonghu` == this.tableName){
        this.$message.error(`账号不能为空`);
        return
      }
      if((!this.regForm.mima) && `yonghu` == this.tableName){
        this.$message.error(`密码不能为空`);
        return
      }
      if((this.regForm.mima!=this.regForm.mima2) && `yonghu` == this.tableName){
	    this.$message.error(`两次密码输入不一致`);
	    return
      }
      if((!this.regForm.xingming) && `yonghu` == this.tableName){
        this.$message.error(`姓名不能为空`);
        return
      }
      if(`yonghu` == this.tableName && this.regForm.youxiang&&(!this.$validate.isEmail(this.regForm.youxiang))){
        this.$message.error(`邮箱应输入邮件格式`);
        return
      }
      if(`yonghu` == this.tableName && this.regForm.shoujihaoma&&(!this.$validate.isMobile(this.regForm.shoujihaoma))){
        this.$message.error(`手机号码应输入手机格式`);
        return
      }
      // if(`yonghu` == this.tableName && this.ruleForm.money&&(!this.$validate.isNumber(this.ruleForm.money))){
      //   this.$message.error(`余额应输入数字`);
      //   return
      // }
      this.$http({
        url: url,
        method: "post",
        data:this.regForm
      }).then(({ data }) => {
        if (data && data.code === 0) {
          this.$message({
            message: "注册成功",
            type: "success",
            duration: 1500,
          })
          this.activeName='first'
          this.regForm=[]

        } else {
          this.$message.error(data.msg);
        }
      });
    },
    
  }
};
</script>
<style lang="scss">
  .element-style{
    
  }
  .el-tabs__item{
    font-size: 18px;
  }
  .el-form-item {
    margin: 22px;
    padding: 6px;
}
.loginIn .left  .el-form-item .el-input{
  margin-left:20px;
}


  .el-button--medium{
    font-size: 18px;
    margin:0px 10px;
  }
  
</style>
<style lang="scss" scoped>
.loginIn {
  min-height: 100vh;
  position: relative;
  background-repeat: no-repeat;
  background-position: center center;
  background-size: cover;
  // background-position:-500px 0px;
  background-image: url("../assets/img/login_bg.jpg");
     

  .loginInBt {
    width: 200px;
    height: 102px;
    line-height: 102px;
    margin: -154px 0 20px 400px;
    padding: 0;
    color: rgba(255, 255, 255, 1);
    font-size: 26px;
    border-radius: 14px;
    border-width: 4px;
    border-style: dashed ;
    border-color: rgba(216, 225, 232, 1);
    background-color: rgba(94, 173, 207, 1);
    box-shadow: 0 0 0px rgba(255,0,0,.1);
    
  }
  .register {
    width: 100px;
    height: 20px;
    line-height: 20px;
    margin: 20px 0 0 55px;
    padding: 0 10px;
    color: rgba(255, 255, 255, 1);
    font-size: 12px;
    border-radius: 2px;
    border-width: 1px;
    border-style: dashed ;
    border-color: rgba(216, 226, 233, 1);
    background-color: rgba(255, 69, 0, 0.68);
    box-shadow: 0 0 6px rgba(255,0,0,0);
	cursor: pointer;
  }
  .reset {
    width: auto;
    height: 20px;
    line-height: 20px;
    margin: -11px 15px 0 0 ;
    padding: 0px 5px;
    color: rgba(255, 255, 255, 1);
    font-size: 12px;
    border-radius: 5px;
    border-width: 1px;
    border-style: dashed ;
    border-color: rgba(216, 225, 232, 1);
    background-color: rgba(255, 215, 0, 1);
    box-shadow: 0 0 6px rgba(255,0,0,0);
  }


  .left {
    position: absolute;
    left: 0;
    top: 0;
	box-sizing: border-box;
	width: 600px;
	height: auto;
	margin: 0;
	padding:20px;
	border-width: 0px;
	border-style: dashed ;
	border-color: hsla(0, 0%, 100%, 0);
	background-color: #ffffffdb;
	box-shadow: 0 0 0px rgba(30, 144, 255, .8);
.el-tabs__item{
  font-size: 18px;
}
    .login-form {
      background-color: transparent;
      width: 100%;
      right: inherit;
      padding: 0;
      box-sizing: border-box;
      display: flex;
	  position: initial;
      justify-content: center;
      flex-direction: column;
    }

    .title-container {
      text-align: center;
      font-size: 24px;

      .title {
        width: 80%;
        line-height: auto;
        margin: 25px auto;
        padding: 0;
        color: rgba(0, 0, 0, 1);
        font-size: 24px;
        border-radius: 0;
        border-width: 0;
        border-style: solid;
        border-color: rgba(0,0,0,.3);
        background-color: rgba(0,0,0,0);
        box-shadow: 0 0 6px rgba(0,0,0,0);
      }
    }

    .el-form-item {
      position: relative;

      & /deep/ .el-form-item__content {
        line-height: initial;
      }

	  & /deep/ .el-radio__label {
	    width: auto;
	    height: 14px;
	    line-height: 14px;
	    margin: 0;
	    padding: 0 0 0 10px;
	    color: rgba(0, 0, 0, 1);
	    font-size: 14px;
	    border-radius: 0;
	    border-width: 0;
	    border-style: solid;
	    border-color: rgba(255, 255, 255, 0);
	    background-color: rgba(255, 255, 255, 0);
	    box-shadow: 0 0 6px rgba(255,0,0,0);
	    text-align: left;
	  }
	  & /deep/ .el-radio.is-checked .el-radio__label {
	    width: auto;
	    height: 14px;
	    line-height: 14px;
	    margin: 0;
	    padding: 0 0 0 10px;
	    color: rgba(94, 173, 207, 1);
	    font-size: 14px;
	    border-radius: 0;
	    border-width: 0;
	    border-style: solid;
	    border-color: rgba(216, 225, 232, 0);
	    background-color: rgba(255, 255, 255, 0);
	    box-shadow: 0 0 6px rgba(255,0,0,0);
	    text-align: left;
	  }
	  & /deep/ .el-radio__inner {
	    width: 15px;
	    height: 14px;
	    margin: 0;
	    padding: 0;
	    border-radius: 100%;
	    border-width: 1px;
	    border-style: solid;
	    border-color: #dcdfe6;
	    background-color: rgba(255, 255, 255, 1);
	    box-shadow: 0 0 6px rgba(255,0,0,0);
	  }
	  & /deep/ .el-radio.is-checked .el-radio__inner {
	    width: 14px;
	    height: 14px;
	    margin: 0;
	    padding: 0;
	    border-radius: 100%;
	    border-width: 1px;
	    border-style: solid;
	    border-color: rgba(94, 173, 207, 1);
	    background-color: rgba(94, 173, 207, 1);
	    box-shadow: 0 0 6px rgba(255,0,0,0);
	  }

      .svg-container {
        padding: 6px 5px 6px 15px;
        color: #889aa4;
        vertical-align: middle;
        display: inline-block;
        position: absolute;
        left: 0;
        top: 0;
        z-index: 1;
        padding: 0;
        line-height: 40px;
        width: 30px;
        text-align: center;
      }

      .el-input {
        display: inline-block;
        // height: 40px;
        width: 100%;

        & /deep/ input {
          background: transparent;
          border: 0px;
          -webkit-appearance: none;
          padding: 0 15px 0 30px;
          color: #fff;
          height: 40px;

		  width: 70%;
		  height: 60px;
		  line-height: 40px;
		  // margin: 0 0 0 30px;
		  padding: 0 30px;
		  color: rgba(0, 0, 0, 1);
		  font-size: 16px;
		  border-width: 1px;
		  border-style: solid;
		  border-color: #c0c4cc;
		  background-color: rgba(255, 255, 255, 0);
		  box-shadow: 0 0 6px rgba(255,0,0,0);
        }
      }

    }


  }

  .center {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate3d(-50%,-50%,0);
  }

  .right {
    position: absolute;
    left: inherit;
    right: 0;
    top: 0;
  }

  .code {
    .el-form-item__content {
      position: relative;

      .getCodeBt {
        position: absolute;
        right: 0;
        top: 50%;
        transform: translate3d(0, -50%, 0);
        line-height: 40px;
        width: 100px;
        background-color: rgba(51,51,51,0.4);
        color: #fff;
        text-align: center;
        border-radius: 0 4px 4px 0;
        height: 40px;
        overflow: hidden;
		padding: 0;
		margin: 0;
		width: 100px;
        height: 30px;
        line-height: 30px;
        border-radius: 0;
        border-width: 0;
        border-style: solid;
        border-color: rgba(64, 158, 255, 1);
        background-color: rgba(51, 51, 51, 0.4);
        box-shadow: 0 0 6px rgba(255,0,0,0);

        span {
          padding: 0 5px;
          display: inline-block;
          font-size: 16px;
          font-weight: 600;
        }
      }

      .el-input {
        & /deep/ input {
          padding: 0 130px 0 30px;
        }
      }
    }
  }

  .setting {
    & /deep/ .el-form-item__content {
      // padding: 0 15px;
      box-sizing: border-box;
      line-height: 32px;
      height: 32px;
      font-size: 14px;
      color: #999;
      margin: 0 !important;
	  display: flex;

      .register {
        // float: left;
        // width: 50%;
		text-align: center;
      }

      .reset {
        float: right;
        width: 50%;
        text-align: right;
      }
    }
  }

  .style2 {
    padding-left: 30px;

    .svg-container {
      left: -30px !important;
    }

    .el-input {
      & /deep/ input {
        padding: 0 15px !important;
      }
    }
  }

  .code.style2, .code.style3 {
    .el-input {
      & /deep/ input {
        padding: 0 115px 0 15px;
      }
    }
  }

  .style3 {
    & /deep/ .el-form-item__label {
      padding-right: 6px;
      height: 30px;
      line-height: 30px;
    }

    .el-input {
      & /deep/ input {
        padding: 0 15px !important;
      }
    }
  }
  // input
  & /deep/ .el-form-item__label {
	width: 30px;
	height: 30px;
	line-height: 30px;
	margin: 0;
	padding: 10px;
	color: rgba(0, 0, 0, 1);
	font-size: 18px;
	border-radius: 0;
	border-width: 0;
	border-style: solid;
	border-color: rgba(0,0,0,0);
	background-color: rgba(0,0,0,0);
	box-shadow: 0 0 6px rgba(0,0,0,0);
  }

  .role {
    & /deep/ .el-form-item__label {
      width: 60px !important;
      height: 38px;
      line-height: 38px;
      margin: 0 10px 0 5px;
      padding: 0;
      color: rgba(0, 0, 0, 1);
      font-size: 14px;
      border-radius: 0;
      border-width: 0;
      border-style: solid;
      border-color: rgba(64, 158, 255, 1);
      background-color: rgba(255, 255, 255, 0);
      box-shadow: 0 0 6px rgba(255,0,0,0);
      text-align: left;
    }

    & /deep/ .el-radio {
      margin-right: 12px;
    }
  }
}
</style>
