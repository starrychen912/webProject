package com.second.hand.trading.server.controller;

import com.second.hand.trading.server.enums.ErrorMsg;
import com.second.hand.trading.server.model.IdleItemModel;
import com.second.hand.trading.server.model.UserItemModel;
import com.second.hand.trading.server.service.CollaborativeAlgorithm;
import com.second.hand.trading.server.service.IdleItemService;
import com.second.hand.trading.server.service.UserItemService;
import com.second.hand.trading.server.service.UserService;
import com.second.hand.trading.server.vo.PageVo;
import com.second.hand.trading.server.vo.ResultVo;
import com.second.hand.trading.server.vo.UserIdleNum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/userItem")
public class UserItemController {

    private static  final Logger LOGGER= LoggerFactory.getLogger(UserItemController.class);

    @Autowired
    private UserItemService userItemService;

    @Autowired
    IdleItemService idleItemService;

    @Autowired
    UserService userService;


    @PostMapping("/add")
    public ResultVo addUserItem(     UserItemModel userItemModel){
        userItemModel.setCreateTime(new Date());
        if(userItemService.addUserItem(userItemModel)){
            return ResultVo.success(userItemModel.getId());
        }
        return ResultVo.fail(ErrorMsg.PARAM_ERROR);
    }

    @GetMapping("/recommend")
    public ResultVo recommend(@CookieValue("shUserId")Integer userId){
        System.out.println("当前登录用户信息为："+userId);
        // 如果用户未登录，则从库里面获取4个返回
        if(userId==null){
            PageVo<IdleItemModel> itemModelPageVo = idleItemService.findIdleItem("", 1, 4);
            List<IdleItemModel> itemModelList = itemModelPageVo.getList();
            checkItemModelList(itemModelList);
            return ResultVo.success(itemModelList);
        }
        //如果用户登录，则尝试进行推荐
        List<Map<String, String>> idleNumList = userItemService.getUserIdleNumList();
        List<UserIdleNum> userIdleNumList=new ArrayList<>();
        for(int i=0;i<idleNumList.size();i++){
            Map<String, String> stringMap = idleNumList.get(i);
            String user_id = String.valueOf(stringMap.get("user_id"));
            String idle_id = String.valueOf(stringMap.get("idle_id"));
            String number = String.valueOf(stringMap.get("number"));
            UserIdleNum userIdleNum=new UserIdleNum();
            userIdleNum.setUserId(Long.parseLong(user_id));
            userIdleNum.setIdleId(Long.parseLong(idle_id));
            userIdleNum.setNumber(Integer.parseInt(number));
            userIdleNumList.add(userIdleNum);
        }
        System.out.println("进行推荐的基础数据为："+userIdleNumList);
        List<String> calculate = CollaborativeAlgorithm.calculate(userId, userIdleNumList);
        System.out.println("获取的推荐结果为："+calculate);
        List<IdleItemModel> itemModelList;
        // 如果推荐结果为空，则从库里面获取4个
        if(calculate==null||calculate.isEmpty()){
            PageVo<IdleItemModel> itemModelPageVo = idleItemService.findIdleItem("", 1, 4);
            itemModelList = itemModelPageVo.getList();
        }else{
            itemModelList= idleItemService.findIdleByList(calculate.stream().map(e -> Long.parseLong(e)).collect(Collectors.toList()));
        }
        checkItemModelList(itemModelList);
        return ResultVo.success(itemModelList);
    }

    // 绑定用户
    private void checkItemModelList(List<IdleItemModel> itemModelList){
        for(IdleItemModel idleItemModel:itemModelList){
            Long userId = idleItemModel.getUserId();
            idleItemModel.setUser(userService.getUser(userId));

        }
    }

    @GetMapping("all")
    public ResultVo getAllIdleItem(@CookieValue("shUserId")
                                   @NotNull(message = "登录异常 请重新登录")
                                   @NotEmpty(message = "登录异常 请重新登录") String shUserId){
        return ResultVo.success(idleItemService.getAllIdelItem(Long.valueOf(shUserId)));
    }

}
