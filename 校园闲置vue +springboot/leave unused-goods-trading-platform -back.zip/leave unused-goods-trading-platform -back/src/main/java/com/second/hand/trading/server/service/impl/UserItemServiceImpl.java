package com.second.hand.trading.server.service.impl;

import com.second.hand.trading.server.dao.UserItemDao;
import com.second.hand.trading.server.dao.IdleItemDao;
import com.second.hand.trading.server.model.UserItemModel;
import com.second.hand.trading.server.model.IdleItemModel;
import com.second.hand.trading.server.service.UserItemService;
import com.second.hand.trading.server.service.UserItemService;
import com.second.hand.trading.server.service.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserItemServiceImpl implements UserItemService {

    @Resource
    private UserItemDao userItemDao;

    @Resource
    private IdleItemDao idleItemDao;

    @Override
    public List<Map<String, String>> getUserIdleNumList() {
        return userItemDao.getUserIdleNumList();
    }

    /**
     * 新增浏览
     * @param userItemModel
     * @return
     */
    public boolean addUserItem(UserItemModel userItemModel){
        return userItemDao.insert(userItemModel)==1;
    }

    /**
     * 删除浏览
     * @param id
     * @return
     */
    public boolean deleteUserItem(Long id){
        return userItemDao.deleteByPrimaryKey(id)==1;
    }


    /**
     * 查询一个用户的所有浏览
     * 关联查询，没有用join，通过where in查询关联的闲置信息
     * @param userId
     * @return
     */
    public List<UserItemModel> getAllUserItem(Long userId){
        List<UserItemModel> list=userItemDao.getListByUser(userId);
        if(list.size()>0){
            for(UserItemModel i:list){
                Long idleId = i.getIdleId();
                IdleItemModel idleItemModel = idleItemDao.selectByPrimaryKey(idleId);
                i.setIdleItem(idleItemModel);
            }
        }
        return list;
    }
}
