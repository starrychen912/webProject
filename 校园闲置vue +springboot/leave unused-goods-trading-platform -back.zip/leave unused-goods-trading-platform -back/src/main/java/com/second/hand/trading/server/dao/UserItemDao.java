package com.second.hand.trading.server.dao;

import com.second.hand.trading.server.model.FavoriteModel;
import com.second.hand.trading.server.model.UserItemModel;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserItemDao {
    int deleteByPrimaryKey(Long id);

    int insert(UserItemModel record);

    int insertSelective(UserItemModel record);

    UserItemModel selectByPrimaryKey(Long id);

    List<UserItemModel> getListByUser(Long userId);

    int updateByPrimaryKeySelective(UserItemModel record);

    int updateByPrimaryKey(UserItemModel record);

    List<Map<String,String>> getUserIdleNumList();
}