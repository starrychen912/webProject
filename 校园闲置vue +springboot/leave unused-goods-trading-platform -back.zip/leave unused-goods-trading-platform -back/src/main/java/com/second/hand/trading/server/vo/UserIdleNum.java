package com.second.hand.trading.server.vo;

/**
 * Created by jianggc at 2022/3/18.
 */
public class UserIdleNum {
    private Long userId;
    private Long idleId;
    private Integer number;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getIdleId() {
        return idleId;
    }

    public void setIdleId(Long idleId) {
        this.idleId = idleId;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    @Override
    public String toString() {
        return "UserIdleNum{" +
                "userId=" + userId +
                ", idleId=" + idleId +
                ", number=" + number +
                '}';
    }
}
