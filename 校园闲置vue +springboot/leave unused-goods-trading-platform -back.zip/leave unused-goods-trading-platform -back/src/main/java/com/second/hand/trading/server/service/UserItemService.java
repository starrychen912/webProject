package com.second.hand.trading.server.service;

import com.second.hand.trading.server.model.UserItemModel;

import java.util.List;
import java.util.Map;

public interface UserItemService {

    List<Map<String,String>> getUserIdleNumList();

    /**
     * 添加浏览
     * @param userItemModel
     * @return
     */
    boolean addUserItem(UserItemModel userItemModel);

    /**
     * 取消浏览
     * @param id
     * @return
     */
    boolean deleteUserItem(Long id);

    /**
     * 获取浏览列表
     * @param userId
     * @return
     */
    List<UserItemModel> getAllUserItem(Long userId);
}
